self.__precacheManifest = [
  {
    "revision": "c01f6e96a34ad5d5f3cb",
    "url": "/static/css/main.2987243f.chunk.css"
  },
  {
    "revision": "c01f6e96a34ad5d5f3cb",
    "url": "/static/js/main.70fe97d8.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "681b51057d74cfa8975d",
    "url": "/static/js/2.65aa1cca.chunk.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "f6af7a5d52d9e4b886884ac446756c75",
    "url": "/index.html"
  }
];